    const throttleFunction = (func, delay) => {
    
        let prev = 0;
        return (...args) => {
            let now = new Date().getTime();
    
            if (now - prev > delay) {
                prev = now;
                return func(...args);
            }
        }
    }
    
    
      
      document.querySelector('#throt').addEventListener("mousemove", throttleFunction((dets) => {
        const imageUrls = [
            "html.jpg",
            "css.jpg",
            "js.jpg",
            "c.webp",
            "java.png",
            "mysql.png",
            "three.png",
            "github.png",
          ];
        // Randomly select an image URL
        const randomImageUrl = imageUrls[Math.floor(Math.random() * imageUrls.length)];
      
        // Create and style the div element
        const div = document.createElement('div');
        div.style.left = dets.clientX + 'px';
        div.style.top = dets.clientY + 'px';
      
        // Create and style the img element
        const img = document.createElement('img');
        img.setAttribute('src', randomImageUrl);
      
        // Append img to div and div to body
        div.appendChild(img);
        div.classList.add('imagediv');
        document.body.appendChild(div);
            gsap.to(img,{
                y:'0',
                duration:2,
                ease: "bounce.out",
                
            })
            gsap.to(img,{
                y:0,

            })
            setTimeout(() => {
                div.remove();
            }, 1200);

               },600));




 